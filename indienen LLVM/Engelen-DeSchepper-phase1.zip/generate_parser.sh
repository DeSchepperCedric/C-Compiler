cd ./antlr_files/
java -jar antlr-4.7.2-complete.jar -Dlanguage=Python3 ./C.g4 -listener -visitor

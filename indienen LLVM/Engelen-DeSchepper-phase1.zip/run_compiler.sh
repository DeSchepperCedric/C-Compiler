python3 run_compiler.py "$1"

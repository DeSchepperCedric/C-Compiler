python3 run_compiler.py ./test_files/comment_import.c

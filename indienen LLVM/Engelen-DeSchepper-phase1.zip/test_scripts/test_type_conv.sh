python3 run_compiler.py ./test_files/type_conv.c

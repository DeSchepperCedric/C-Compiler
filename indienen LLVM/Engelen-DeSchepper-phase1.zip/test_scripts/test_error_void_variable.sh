python3 run_compiler.py ./test_files/error_void_variable.c

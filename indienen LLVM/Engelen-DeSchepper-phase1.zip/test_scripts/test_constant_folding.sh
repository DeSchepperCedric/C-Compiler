python3 run_compiler.py ./test_files/constant_folding.c

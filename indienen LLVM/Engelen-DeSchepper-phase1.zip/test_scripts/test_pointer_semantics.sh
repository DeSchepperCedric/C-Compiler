python3 run_compiler.py ./test_files/pointer_semantics.c

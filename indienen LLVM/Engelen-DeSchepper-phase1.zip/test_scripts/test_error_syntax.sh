python3 run_compiler.py ./test_files/error_syntax.c

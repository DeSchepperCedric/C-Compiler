/**
 * @file: file to demonstate that type-incorrect expressions are
 * detected and reported.
 */

#include <stdio.h>

void func()
{
    int i = 60;

    char* c = 

}

int main(int arc, char** argv)
{}

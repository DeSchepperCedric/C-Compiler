/**
 * @file: file to demonstate that syntax errors are reported.
 */

#include <stdio.h>

int x // error: missing semicolon

int main(int arc, char** argv)
{}



/**
 * @file: file to demonstate that single line comments,
 * multi-line comments and include statements work.
 */ 


#include <stdio.h>

/**
 * Some comments.
 *
 */

int c;

// another comment.


int main(int arc, char** argv)
{}

